PRELUDE:

1. See if you can run `make' properly on your machine. If not, install the 
appropriate libraries.
2. We provide a simple flex/bison-based parser that computes the result of
arithmetic expressions that feature addition and multiplication (no brackets).
3. The program `calc' takes input from stdin, so you can feed it a program as
follows: `./calc < [input_file]'.

TASK:

Your task is to handle the ``test'' file properly, including the following 
requirements: 

1. You must print out all the values of computations involving '+' and '*',
each on a newline.
2. You must handle comments of the form ``/* */'' properly. Comments may be
nested. Anything inside a comment cannot be printed.
3. If a character outside of '+', '*', or an integer is located outside of a
comment, an error must be triggered.
