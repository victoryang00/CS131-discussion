/* heading.h */
/* Author: Lan Gao (Modifications by J. Cai and M. Lohstroh ) */
using namespace std;

#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

#define YY_NO_UNPUT

extern "C" int yylex(void);
